/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ice4j;

/**
 *
 * @author SUN
 */
public class Log {

    static void i(String tag, String string) {
        System.out.println(tag+":" + string);
    }
    
}
