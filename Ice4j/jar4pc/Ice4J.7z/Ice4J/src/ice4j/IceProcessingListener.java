/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ice4j;

import static ice4j.IceTest.startTime;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.util.List;
import org.ice4j.ice.Agent;
import org.ice4j.ice.Component;
import org.ice4j.ice.IceMediaStream;
import org.ice4j.ice.IceProcessingState;

    /**
     * The listener that would end example execution once we enter the
     * completed state.
     */
    public final class IceProcessingListener implements PropertyChangeListener {
    private String tag = IceProcessingListener.class.getSimpleName();
        /**
         * System.exit()s as soon as ICE processing enters a final state.
         *
         * @param evt the {@link PropertyChangeEvent} containing the old and new
         * states of ICE processing.
         */
        public void propertyChange(PropertyChangeEvent evt)
        {
            long processingEndTime = System.currentTimeMillis();

            Object iceProcessingState = evt.getNewValue();

            Log.i(tag,"Agent entered the " + iceProcessingState + " state.");
            if(iceProcessingState == IceProcessingState.COMPLETED)
            {
            	Log.i(tag,"Total ICE processing time: "+ (processingEndTime - startTime) + "ms");
                Agent agent = (Agent)evt.getSource();
                List<IceMediaStream> streams = agent.getStreams();

                for(IceMediaStream stream : streams)
                {
                    String streamName = stream.getName();
                    Log.i(tag,"Pairs selected for stream: " + streamName);
                    List<Component> components = stream.getComponents();

                    for(Component cmp : components)
                    {
                        String cmpName = cmp.getName();
                        Log.i(tag,cmpName + ": " + cmp.getSelectedPair());
                    }
                }

                Log.i(tag,"Printing the completed check lists:");
                for(IceMediaStream stream : streams)
                {
                    String streamName = stream.getName();
                    Log.i(tag,"Check list for  stream: " + streamName);
                    //uncomment for a more verbose output
                    Log.i(tag,stream.getCheckList().toString());
                }

                Log.i(tag,"Total ICE processing time to completion: "+ (System.currentTimeMillis() - startTime));
            }
            else if(iceProcessingState == IceProcessingState.TERMINATED
                    || iceProcessingState == IceProcessingState.FAILED)
            {
                /*
                 * Though the process will be instructed to die, demonstrate
                 * that Agent instances are to be explicitly prepared for
                 * garbage collection.
                 */
                ((Agent) evt.getSource()).free();
                Log.i(tag,"Total ICE processing time: "+ (System.currentTimeMillis() - startTime));
                //System.exit(0);
            }
        }
    }