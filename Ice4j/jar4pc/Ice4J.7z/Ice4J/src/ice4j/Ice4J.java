package ice4j;

import cat.app.net.p2p.Peer;

public class Ice4J {
    
    public static void main(String[] args) throws Throwable {
        Peer p1 = new Peer();
        p1.startReciever();
        p1.startSender();
    }
    
}
