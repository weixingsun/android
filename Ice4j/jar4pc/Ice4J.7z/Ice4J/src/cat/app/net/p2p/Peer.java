package cat.app.net.p2p;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.ice4j.pseudotcp.PseudoTcpSocket;
import org.ice4j.pseudotcp.PseudoTcpSocketFactory;


public class Peer {
    IceClient client;
    final DatagramSocket socket;
    final SocketAddress remoteAddress;
    final PseudoTcpSocket tcpSocket = null;
    private int TEST_BYTES_COUNT = 2048;
    
    public Peer() throws Throwable{
        client = new IceClient(8888, "data");
        client.init();
        client.exchangeSdpWithPeer();
        client.startConnect();
        socket = client.getDatagramSocket();
        remoteAddress = client.getRemotePeerSocketAddress();
        //System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>SOCKET:"+socket.toString());
        
        /*tcpSocket = new PseudoTcpSocketFactory().createSocket(socket);
                            tcpSocket.setConversationID(1073741824);
                            tcpSocket.setMTU(1500);
                            tcpSocket.setDebugName("L");
                            tcpSocket.accept(5000);*/
    }
    public void listenUdp(byte[] buf){
        try {
            DatagramPacket packet = new DatagramPacket(buf,buf.length);
            socket.receive(packet);
            System.out.println(">>>>>>>>>>>>>>>>>receive:"+ new String(packet.getData(), 0, packet.getLength())+ ": "+formatTime());
            TimeUnit.SECONDS.sleep(10);
        } catch (IOException | InterruptedException e) {
        }
    }
    public void listenTcp(byte[] buf){
        try {
            DatagramPacket packet = new DatagramPacket(buf,buf.length);
                byte[] buffer = new byte[TEST_BYTES_COUNT];
                int read = 0;
                while (read != TEST_BYTES_COUNT) {
                    read += tcpSocket.getInputStream().read(buffer);
                    //logger.log(Level.FINEST, "Local job read: " + read);
                }
            tcpSocket.getInputStream().read(buf, 0, packet.getLength());
            System.out.println(">>>>>>>>>>>>>>>>>receive:"+ new String(packet.getData(), 0, packet.getLength()));
            TimeUnit.SECONDS.sleep(10);
        } catch (IOException | InterruptedException e) {
        }
    }
    public void startReciever(){
        new Thread(new Runnable() {
            byte[] buf = new byte[1024];
            public void run() {
                 while (true) {
                    listenUdp(buf);
                    
                 }
            }
        }).start();
    }
    public void startSender(){
        new Thread(new Runnable() {
            public void run() {
                 int count = 1;
                 while (true) {
                      try {
                          String time = formatTime();
                           byte[] buf = ("msg sent at: " + time).getBytes();
                           DatagramPacket packet = new DatagramPacket(buf,buf.length);
                           packet.setSocketAddress(remoteAddress);
                           socket.send(packet);
                           System.out.println("send "+time);
                           TimeUnit.SECONDS.sleep(30);
                      } catch (Exception e) {
                           e.printStackTrace();
                      }

                 }
            }
        }).start();
    }

    private String formatTime(){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        Calendar c = Calendar.getInstance();
        return sdf.format(c.getTime());
    }
}
