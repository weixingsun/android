package cat.app.net.p2p;


import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketAddress;
import java.util.concurrent.TimeUnit;


public class Peer {
    IceClient client;
    final DatagramSocket socket;
    final SocketAddress remoteAddress;
    
    public Peer() throws Throwable{
        client = new IceClient(8888, "text");
        client.init();
        client.exchangeSdpWithPeer();
        client.startConnect();
        socket = client.getDatagramSocket();
        remoteAddress = client.getRemotePeerSocketAddress();
        System.out.println(">>>>>>>>>>>>>>>>>>>>>>>>>SOCKET:"+socket.toString());
    }
    
    public void startReciever(){
        new Thread(new Runnable() {
            byte[] buf = new byte[1024];
            public void run() {
                 while (true) {
                      try {
                           DatagramPacket packet = new DatagramPacket(buf,buf.length);
                           socket.receive(packet);
                           System.out.println(">>>>>>>>>>>>>>>>>receive:"+ new String(packet.getData(), 0, packet.getLength()));
                           
                           TimeUnit.SECONDS.sleep(10);
                      } catch (Exception e) {
                           e.printStackTrace();
                      }
                 }
            }
        }).start();
    }
    public void startSender(){
        new Thread(new Runnable() {
            public void run() {
                 int count = 1;
                 while (true) {
                      try {
                           byte[] buf = ("send msg " + count++ + "").getBytes();
                           DatagramPacket packet = new DatagramPacket(buf,buf.length);
                           packet.setSocketAddress(remoteAddress);
                           socket.send(packet);
                           System.out.println("send test msg");
                           TimeUnit.SECONDS.sleep(30);
                      } catch (Exception e) {
                           e.printStackTrace();
                      }

                 }
            }
        }).start();
    }

}
