package cat.app.net.p2p;

class Log {
    static void i(String tag, String text) {
        System.out.println(text);
    }
}
