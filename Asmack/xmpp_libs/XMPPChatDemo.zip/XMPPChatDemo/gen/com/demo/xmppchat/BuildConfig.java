/** Automatically generated file. DO NOT MODIFY */
package com.demo.xmppchat;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}